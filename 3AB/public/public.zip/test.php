<?php
mkdir("test");
?>