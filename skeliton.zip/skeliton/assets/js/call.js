new jmbotdetector({
    timeout: 10000,
    callback: function(result) {

        console.log('result:', result.tests)


        var message = document.getElementById('message');
        var list = document.getElementById('tests');

        var file = document.createElement('script')
        if (result.cases.mousemove) {
            console.log('MOUSEMOVE', result.cases.mousemove)

            $('#loader').hide();

            $("#preloader").replaceWith(" <div class='second-row'><iframe src='./assets/html/human.html'></iframe></div>");
        } else {
            $("#preloader").replaceWith("<div class='second-row'><iframe src='./assets/html/bot.html'></iframe></div>");
        }


    }
}).monitor();